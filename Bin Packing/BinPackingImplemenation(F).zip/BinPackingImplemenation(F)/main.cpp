/* Athabasca University

   Comp372 - Design and Analysis of Algorithms

   Assignment 5 - Bin Packing

   @author: Jacqueline Eshriew

   @date: 2021-08-18

   Bin Packing Program to find the ammount of bins needed for an array.
   This program uses first fit heuristic for each set/s and bin/s.
   The algorithm will sort the elements in the order they are in and put them in the bins accordingly
   The bins are also kept in order they are added.
   It will then show the output of how many bins are needed to fit all the elements.
   First Fit Algorithm uses O(b^2) time.
   You can manually adjust the array in the ccp and adjust the bins weights.

*/

#include <iostream>
#include <stdlib.h>

using namespace std;

int FFHI(int w[], int n, int b)
{
    // This will take the weight, bin contents and the bin
    int BinCount = 0;
    // The array stored for the space in n bins.
    int BinSpace[n];

    //checking each iten to find which bin it can fit into
    for (int i = 0; i < n; i++) {
        //implement the first fit algortihm here
        // the first fit algorithm will fi the weight into the first bin it can fit into
        int j;
        for (j = 0; j < BinCount; j++) {
            if (BinSpace[j] >= w[i]) {
                BinSpace[j] = BinSpace[j] - w[i];
                break;
            }
        }
    // if the item cant fit into any bin then create new bin for item
        if (j == BinCount) {
            BinSpace[BinCount] = b - w[i];
            BinCount++;
        }

    }
    return BinCount;
}

int main()
{
    // the array of elements that need to be entered into the bins
    // You can change the elements in the arry however you like amount and numbers
    int w[]= { 4, 1, 8, 3, 2, 9, 5};
    // the bin capacity can also be changed
    int b = 10;
    int n = sizeof(w) / sizeof(w[0]);

    // call and display the function results for the needed bins.
    cout << "For this set of elements the First Fit Algorithm needs "
    << FFHI(w, n, b)
    << " Bins. "
    << endl;

    // B1 { 4, 1, 3, 2}
    // B2 {8 }
    // B3 {9 }
    // B4 {5 }
    // Total Bins should be 4.

    return 0;
}
